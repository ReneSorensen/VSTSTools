This extension includes the following tasks

* SQPplus Executer
	
## SQPplus Executer
Execute file or sorted files in folder using application SQLPlus.

## Features
Execute file or files in folder.
Set types of files that will executed

Any directory can be specified as git source folder.

### Prerequisites

* SQPplus must be installed and mapped
* Allow scripts to access Oauth must be **Enabled**
* Project Collection Build Service must have **Contribute** & **Create Tag** set to **Allow** or **Inherit Allow** for that particular repository

## Credits
<div>Icons made by <a href="https://www.iconfinder.com/yanlu" title="Yannick Lung">Yannick Lung</a> from <a href="https://www.iconfinder.com/icons/315437/document_file_sql_icon" title="sql icon">www.iconfinder.com</a> Free for commercial use</div>
